#ifdef CHASTE_CVODE
{% include "Shared/hpp/header_comments" %}
{% include "Shared/hpp/includes" %}
#include "{{base_class}}.hpp"
{% include "Shared/hpp/class_declaration" %}
{% include "Cvode/hpp/public" %}